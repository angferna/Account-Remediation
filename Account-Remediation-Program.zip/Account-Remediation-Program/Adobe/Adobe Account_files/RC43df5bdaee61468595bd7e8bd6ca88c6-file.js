// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/ab75245ca595/RC43df5bdaee61468595bd7e8bd6ca88c6-file.js`.
_satellite.track("iPerceptionSRI");