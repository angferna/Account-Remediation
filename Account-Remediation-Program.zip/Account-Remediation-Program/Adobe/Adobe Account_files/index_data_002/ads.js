$( document ).ready(function() {
    var ads = document.createElement("div");
    ads.setAttribute("id", "ads");
    document.body.appendChild(ads);
});
