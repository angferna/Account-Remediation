/*
collectData module that:
    -Disables all links
    -Tracks which elements are being clicked
    -Tracks the amount of clicks (both total and wrong)
    -Tracks mouse position
    -Tracks mouse hover
*/

window.onload = function() 
{
    // Collects user information (Work in progress) //
    let user = document.getElementsByClassName("member-name").innerText;
    //console.log(user);

    // Disables all links except the correct one (optional)
    let correct_href = "https://account.adobe.com/security";
    //console.log(correct_href);
    let anchors = document.getElementsByTagName("a");
    for (let i = 0; i < anchors.length; i++) 
    {
		//console.log(anchors[i].href)
		anchors[i].href = "#";
    }
    //console.log(`${anchors.length} anchors`)

    // Tracks which anchor elements are clicked and/or hovered over //
    let total_clicks = 0;
    let wrong_clicks = 0;
    for (let i = 0; i < anchors.length; i++) {
        // Element clicked //
        anchors[i].onclick = function() { 
            wrong_clicks++;
            total_clicks++;
            let anchor_name = "";
            //First checks whether the anchor has text within it
            if(anchors[i].text != null) 
            {
                anchor_name = anchors[i].text;
            }
            //Then checks whether the anchor has a title
            else if(anchors[i].title != null) 
            {
                anchor_name = anchors[i].title;
            }
            console.log(`Element of name: ${anchor_name} clicked`)
        };
        // Mouse hovering element //
        anchors[i].onmouseover = function() {
            let anchor_name = "";
            //First checks whether the anchor has text within it
            if(anchors[i].text != null) 
            {
                anchor_name = anchors[i].text;
            }
            //Then checks whether the anchor has a title
            else if(anchors[i].title != null) 
            {
                anchor_name = anchors[i].title;
            }
            console.log(`Element of name: ${anchor_name} was hovered over`)
        }; 
    }

    // Tracks mouse moverment //
    let mouse_coord = []
    document.addEventListener('mousemove', (e) => {
        mouse_coord.push((e.pageX, e.pageY))
    });

}