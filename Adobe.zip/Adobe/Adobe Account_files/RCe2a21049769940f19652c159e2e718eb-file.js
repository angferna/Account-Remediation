// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/ab75245ca595/RCe2a21049769940f19652c159e2e718eb-file.js`.
_satellite.track("clicktaleSRI");